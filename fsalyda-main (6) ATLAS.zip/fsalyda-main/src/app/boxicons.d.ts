declare module "boxicons" {
    export type IconName = string;
}