export default function Denied() {
  return (
    <div className="w-full h-full flex items-center justify-center text-5xl font-bold bg-slate-500">
      Access denied
    </div>
  );
}
