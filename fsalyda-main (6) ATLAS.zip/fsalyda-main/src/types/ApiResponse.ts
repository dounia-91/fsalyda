export interface ApiResponse {
  success: boolean;
  message: string;
}
