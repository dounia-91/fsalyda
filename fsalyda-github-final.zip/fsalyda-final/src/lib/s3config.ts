"use server";
/**
 * s3config.ts
 * Fonctions utilitaires pour interagir avec AWS S3.
 * Toutes les opérations se font côté serveur (Server Actions).
 */
import { DeleteObjectCommand, S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { v4 as uuidv4 } from "uuid";

/** Crée un client S3 avec les variables d'environnement */
const createS3Client = () =>
  new S3Client({
    region: process.env.AWS_REGION!,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
    },
  });

const BUCKET = () => process.env.AWS_S3_BUCKET || process.env.AWS_BUCKET_NAME || "";

/**
 * Upload un fichier (File) vers S3.
 * Retourne la clé S3 et l'URL publique en cas de succès.
 */
export const uploadFileToS3 = async (file: File) => {
  try {
    const s3 = createS3Client();
    const bucket = BUCKET();

    if (!bucket) throw new Error("Bucket S3 non configuré (AWS_S3_BUCKET)");

    const ext = file.name.split('.').pop() || 'bin';
    const key = `uploads/${uuidv4()}.${ext}`;

    const arrbuf = await file.arrayBuffer();
    const buffer = new Uint8Array(arrbuf);

    await s3.send(new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: buffer,
      ContentType: file.type || "application/octet-stream",
    }));

    const url = `https://${bucket}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
    return { success: true, status: 200, key, url };
  } catch (error) {
    console.error("Erreur upload S3:", error);
    return { success: false, status: 500, error };
  }
};

/**
 * Upload un Blob (enregistrement audio) vers S3.
 * Retourne la clé S3 et l'URL publique.
 */
export const uploadBlobToS3 = async (blob: Blob, fileType: string = "audio/webm") => {
  try {
    const s3 = createS3Client();
    const bucket = BUCKET();

    if (!bucket) throw new Error("Bucket S3 non configuré");

    const ext = fileType.includes("webm") ? "webm" : fileType.split("/")[1] || "bin";
    const key = `uploads/recording-${uuidv4()}.${ext}`;

    const arrbuf = await blob.arrayBuffer();
    const buffer = new Uint8Array(arrbuf);

    await s3.send(new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: buffer,
      ContentType: fileType,
    }));

    const url = `https://${bucket}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
    return { success: true, status: 200, key, url };
  } catch (error) {
    console.error("Erreur upload Blob S3:", error);
    return { success: false, status: 500, error };
  }
};

/**
 * Supprime un fichier de S3 par sa clé.
 */
export const deleteFileFromS3 = async (key: string) => {
  try {
    const s3 = createS3Client();
    await s3.send(new DeleteObjectCommand({
      Bucket: BUCKET(),
      Key: key.trim(),
    }));
    return { success: true, status: 200, message: "Fichier supprimé avec succès" };
  } catch (error) {
    console.error("Erreur suppression S3:", error);
    return { success: false, status: 500, error };
  }
};

/**
 * Génère une URL pré-signée pour accès temporaire à un fichier S3 privé.
 * Expire après 1 heure par défaut.
 */
export const getPresignedReadUrl = async (key: string, expiresIn = 3600): Promise<string> => {
  const s3 = createS3Client();
  const command = new GetObjectCommand({
    Bucket: BUCKET(),
    Key: key,
  });
  return getSignedUrl(s3, command, { expiresIn });
};

/**
 * Génère une URL pré-signée pour upload direct depuis le client.
 * Appelle /api/get-presigned-url côté client (ne pas appeler directement depuis serveur).
 */
export const getPresignedUrl = async (filename: string) => {
  const res = await fetch('/api/get-presigned-url', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ filename }),
  });
  return res.json();
};
