"use client";
/**
 * Page de formulaire partagé via lien public.
 * Accessible sans authentification.
 * Affiche le formulaire en lecture seule + section commentaires.
 */
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { Loader2, Lock, MessageSquare, Send } from "lucide-react";

interface Comment {
  author: string;
  text: string;
  createdAt: string;
}

interface SharedForm {
  _id: string;
  title: string;
  companyName: string;
  filledBy: string;
  formItemDetails: unknown[];
  formState: Record<string, unknown>;
  isLocked: boolean;
  comments: Comment[];
  createdAt: string;
}

export default function SharedFormPage() {
  const { token } = useParams<{ token: string }>();
  const [form, setForm] = useState<SharedForm | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Commentaire
  const [commentAuthor, setCommentAuthor] = useState("");
  const [commentText, setCommentText] = useState("");
  const [submittingComment, setSubmittingComment] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);

  useEffect(() => {
    const fetchForm = async () => {
      try {
        const res = await fetch(`/api/share?token=${token}`);
        const data = await res.json();
        if (data.success) {
          setForm(data.form);
          setComments(data.form.comments || []);
        } else {
          setError(data.message || "Lien invalide ou expiré");
        }
      } catch {
        setError("Erreur de chargement du formulaire");
      } finally {
        setLoading(false);
      }
    };
    if (token) fetchForm();
  }, [token]);

  const submitComment = async () => {
    if (!commentAuthor.trim() || !commentText.trim()) return;
    setSubmittingComment(true);
    try {
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          formId: form?._id,
          author: commentAuthor.trim(),
          text: commentText.trim(),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setComments((prev) => [...prev, data.comment]);
        setCommentText("");
      }
    } catch {
      alert("Erreur lors de l'envoi du commentaire");
    } finally {
      setSubmittingComment(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin mr-2" />
        <span>Chargement...</span>
      </div>
    );
  }

  if (error || !form) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center p-8 bg-red-50 rounded-lg">
          <p className="text-red-600 font-bold text-lg">{error}</p>
          <p className="text-gray-500 mt-2">Ce lien n&apos;est pas valide ou a expiré.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* En-tête formulaire */}
        <div className="bg-white rounded-xl shadow p-6">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-2xl font-bold text-gray-800">{form.title}</h1>
            {form.isLocked && (
              <span className="flex items-center gap-1 text-sm text-orange-600 bg-orange-100 px-2 py-1 rounded">
                <Lock size={14} />
                Verrouillé
              </span>
            )}
          </div>
          <p className="text-sm text-gray-500">
            Entreprise : <strong>{form.companyName}</strong> · Soumis le{" "}
            {new Date(form.createdAt).toLocaleDateString("fr-FR")}
          </p>
        </div>

        {/* Données du formulaire */}
        <div className="bg-white rounded-xl shadow p-6 space-y-4">
          <h2 className="font-semibold text-gray-700 border-b pb-2">Données du formulaire</h2>
          {Object.entries(form.formState).map(([key, value]) => (
            <div key={key} className="flex flex-col">
              <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">{key}</span>
              <span className="text-gray-800 mt-1">
                {Array.isArray(value)
                  ? value.join(", ") || "—"
                  : typeof value === "boolean"
                  ? value ? "Oui" : "Non"
                  : String(value) || "—"}
              </span>
            </div>
          ))}
        </div>

        {/* Section commentaires */}
        <div className="bg-white rounded-xl shadow p-6 space-y-4">
          <h2 className="font-semibold text-gray-700 border-b pb-2 flex items-center gap-2">
            <MessageSquare size={18} />
            Commentaires ({comments.length})
          </h2>

          {comments.length === 0 && (
            <p className="text-sm text-gray-400">Aucun commentaire pour l&apos;instant.</p>
          )}

          {comments.map((c, i) => (
            <div key={i} className="bg-gray-50 rounded-lg p-3">
              <div className="flex justify-between items-start">
                <span className="font-medium text-gray-700 text-sm">{c.author}</span>
                <span className="text-xs text-gray-400">
                  {new Date(c.createdAt).toLocaleDateString("fr-FR")}
                </span>
              </div>
              <p className="text-gray-600 mt-1 text-sm">{c.text}</p>
            </div>
          ))}

          {/* Formulaire de commentaire (désactivé si verrouillé) */}
          {!form.isLocked && (
            <div className="space-y-2 pt-2 border-t">
              <input
                type="text"
                placeholder="Votre nom"
                value={commentAuthor}
                onChange={(e) => setCommentAuthor(e.target.value)}
                className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
              />
              <textarea
                placeholder="Votre commentaire..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                rows={3}
                className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 resize-none"
              />
              <button
                onClick={submitComment}
                disabled={submittingComment || !commentAuthor.trim() || !commentText.trim()}
                className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submittingComment ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                Envoyer
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
