import { NextRequest, NextResponse } from "next/server";
import dbConnect from "@/lib/dbConnect";
import FilledFormModel from "@/model/filledForm";

/**
 * GET /api/history?email=xxx&companyName=xxx
 * Retourne l'historique des formulaires soumis par un utilisateur ou une entreprise.
 * Si companyName=fsalyda (admin), retourne tout.
 */
export async function GET(req: NextRequest) {
  await dbConnect();
  try {
    const { searchParams } = new URL(req.url);
    const email = searchParams.get("email");
    const companyName = searchParams.get("companyName");

    if (!email && !companyName) {
      return NextResponse.json({ success: false, message: "email ou companyName requis" }, { status: 400 });
    }

    let query: Record<string, unknown> = {};
    if (companyName === "fsalyda") {
      // Admin: tout voir
      query = {};
    } else if (email) {
      // Utilisateur: ses propres soumissions
      query = { filledBy: email };
    } else if (companyName) {
      // Manager: toute l'entreprise
      query = { companyName };
    }

    const forms = await FilledFormModel.find(query)
      .select("title companyName filledBy createdAt isLocked shareToken")
      .sort({ createdAt: -1 })
      .limit(100);

    return NextResponse.json({ success: true, forms }, { status: 200 });
  } catch (error) {
    console.error("Erreur récupération historique:", error);
    return NextResponse.json({ success: false, message: "Erreur serveur" }, { status: 500 });
  }
}
