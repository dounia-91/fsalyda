import { NextRequest, NextResponse } from "next/server";
import dbConnect from "@/lib/dbConnect";
import FilledFormModel from "@/model/filledForm";
import { v4 as uuidv4 } from "uuid";

/**
 * POST /api/share
 * Génère un token de partage pour un formulaire rempli.
 * Body: { formId: string }
 * Retourne: { shareToken: string, shareUrl: string }
 */
export async function POST(req: NextRequest) {
  await dbConnect();
  try {
    const { formId } = await req.json();
    if (!formId) {
      return NextResponse.json({ success: false, message: "formId requis" }, { status: 400 });
    }

    const form = await FilledFormModel.findById(formId);
    if (!form) {
      return NextResponse.json({ success: false, message: "Formulaire introuvable" }, { status: 404 });
    }

    // Générer ou réutiliser le token
    if (!form.shareToken) {
      form.shareToken = uuidv4();
      await form.save();
    }

    const baseUrl = process.env.NEXTAUTH_URL || "http://localhost:3000";
    const shareUrl = `${baseUrl}/shared/${form.shareToken}`;

    return NextResponse.json({ success: true, shareToken: form.shareToken, shareUrl }, { status: 200 });
  } catch (error) {
    console.error("Erreur génération lien de partage:", error);
    return NextResponse.json({ success: false, message: "Erreur serveur" }, { status: 500 });
  }
}

/**
 * GET /api/share?token=xxx
 * Récupère un formulaire via son token de partage public.
 */
export async function GET(req: NextRequest) {
  await dbConnect();
  try {
    const token = new URL(req.url).searchParams.get("token");
    if (!token) {
      return NextResponse.json({ success: false, message: "Token manquant" }, { status: 400 });
    }

    const form = await FilledFormModel.findOne({ shareToken: token });
    if (!form) {
      return NextResponse.json({ success: false, message: "Lien invalide ou expiré" }, { status: 404 });
    }

    // Ne pas retourner les données sensibles si le formulaire est verrouillé
    return NextResponse.json({ success: true, form }, { status: 200 });
  } catch (error) {
    console.error("Erreur récupération formulaire partagé:", error);
    return NextResponse.json({ success: false, message: "Erreur serveur" }, { status: 500 });
  }
}
