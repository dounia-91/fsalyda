import { NextRequest, NextResponse } from "next/server";
import dbConnect from "@/lib/dbConnect";
import FilledFormModel from "@/model/filledForm";

/**
 * POST /api/lockForm
 * Verrouille ou déverrouille un formulaire rempli.
 * Body: { formId: string, lock: boolean }
 * Un formulaire verrouillé est en lecture seule et ne peut plus être modifié.
 */
export async function POST(req: NextRequest) {
  await dbConnect();
  try {
    const { formId, lock } = await req.json();

    if (!formId || typeof lock !== "boolean") {
      return NextResponse.json({ success: false, message: "formId et lock (boolean) requis" }, { status: 400 });
    }

    const form = await FilledFormModel.findByIdAndUpdate(
      formId,
      { isLocked: lock, lockedAt: lock ? new Date() : null },
      { new: true }
    );

    if (!form) {
      return NextResponse.json({ success: false, message: "Formulaire introuvable" }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      message: lock ? "Formulaire verrouillé" : "Formulaire déverrouillé",
      isLocked: form.isLocked,
    }, { status: 200 });
  } catch (error) {
    console.error("Erreur verrouillage formulaire:", error);
    return NextResponse.json({ success: false, message: "Erreur serveur" }, { status: 500 });
  }
}
