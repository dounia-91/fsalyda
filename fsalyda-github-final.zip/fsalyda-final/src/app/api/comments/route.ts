import { NextRequest, NextResponse } from "next/server";
import dbConnect from "@/lib/dbConnect";
import FilledFormModel from "@/model/filledForm";

/**
 * POST /api/comments
 * Ajoute un commentaire sur un formulaire partagé.
 * Body: { formId: string, author: string, text: string }
 *
 * GET /api/comments?formId=xxx
 * Récupère les commentaires d'un formulaire.
 */
export async function POST(req: NextRequest) {
  await dbConnect();
  try {
    const { formId, author, text } = await req.json();

    if (!formId || !author || !text?.trim()) {
      return NextResponse.json({ success: false, message: "formId, author et text requis" }, { status: 400 });
    }

    const form = await FilledFormModel.findById(formId);
    if (!form) {
      return NextResponse.json({ success: false, message: "Formulaire introuvable" }, { status: 404 });
    }

    if (form.isLocked) {
      return NextResponse.json({ success: false, message: "Ce formulaire est verrouillé" }, { status: 403 });
    }

    const comment = {
      author,
      text: text.trim(),
      createdAt: new Date(),
    };

    if (!form.comments) form.comments = [];
    form.comments.push(comment);
    await form.save();

    return NextResponse.json({ success: true, comment, message: "Commentaire ajouté" }, { status: 200 });
  } catch (error) {
    console.error("Erreur ajout commentaire:", error);
    return NextResponse.json({ success: false, message: "Erreur serveur" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  await dbConnect();
  try {
    const formId = new URL(req.url).searchParams.get("formId");
    if (!formId) {
      return NextResponse.json({ success: false, message: "formId requis" }, { status: 400 });
    }

    const form = await FilledFormModel.findById(formId).select("comments");
    if (!form) {
      return NextResponse.json({ success: false, message: "Formulaire introuvable" }, { status: 404 });
    }

    return NextResponse.json({ success: true, comments: form.comments || [] }, { status: 200 });
  } catch (error) {
    console.error("Erreur récupération commentaires:", error);
    return NextResponse.json({ success: false, message: "Erreur serveur" }, { status: 500 });
  }
}
