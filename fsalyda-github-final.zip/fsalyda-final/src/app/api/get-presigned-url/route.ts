import { NextRequest, NextResponse } from 'next/server';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

/**
 * POST /api/get-presigned-url
 * Génère une URL pré-signée pour upload direct vers S3 depuis le client.
 * Body JSON: { filename: string, contentType: string }
 */
export async function POST(req: NextRequest) {
  try {
    const { filename, contentType } = await req.json();

    if (!filename) {
      return NextResponse.json({ error: 'filename requis' }, { status: 400 });
    }

    const bucket = process.env.AWS_S3_BUCKET || process.env.AWS_BUCKET_NAME;
    const region = process.env.AWS_REGION;

    if (!bucket || !region) {
      return NextResponse.json({ error: 'Configuration AWS incomplète' }, { status: 500 });
    }

    const s3 = new S3Client({
      region,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
      },
    });

    const key = `audio/${filename}`;
    const command = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      ContentType: contentType || 'audio/webm',
    });

    const presignedUrl = await getSignedUrl(s3, command, { expiresIn: 300 }); // 5 min
    const fileUrl = `https://${bucket}.s3.${region}.amazonaws.com/${key}`;

    return NextResponse.json({ url: presignedUrl, fileUrl }, { status: 200 });
  } catch (error) {
    console.error('Presigned URL error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
