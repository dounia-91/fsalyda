import { NextResponse } from 'next/server';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { v4 as uuidv4 } from 'uuid';

/**
 * POST /api/upload
 * Upload un fichier vers AWS S3 et retourne la clé S3 et l'URL publique.
 * Accepte un FormData avec un champ "file".
 */
export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get('file');

    if (!file || !(file instanceof Blob)) {
      return NextResponse.json({ error: 'Fichier manquant' }, { status: 400 });
    }

    // Vérifier les variables d'environnement
    const region = process.env.AWS_REGION;
    const bucket = process.env.AWS_S3_BUCKET || process.env.AWS_BUCKET_NAME;
    const accessKeyId = process.env.AWS_ACCESS_KEY_ID;
    const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;

    if (!region || !bucket || !accessKeyId || !secretAccessKey) {
      console.error('Variables AWS manquantes:', { region, bucket, accessKeyId: !!accessKeyId });
      return NextResponse.json({ error: 'Configuration AWS incomplète' }, { status: 500 });
    }

    const s3Client = new S3Client({
      region,
      credentials: { accessKeyId, secretAccessKey },
    });

    // Récupérer le nom et type du fichier
    const fileName = (file as File).name || 'file';
    const contentType = file.type || 'application/octet-stream';
    const ext = fileName.split('.').pop();
    const key = `uploads/${uuidv4()}.${ext}`;

    const arrayBuffer = await file.arrayBuffer();
    const buffer = new Uint8Array(arrayBuffer);

    await s3Client.send(new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: buffer,
      ContentType: contentType,
    }));

    // URL publique S3 (si le bucket est public) ou via image-proxy
    const url = `https://${bucket}.s3.${region}.amazonaws.com/${key}`;

    return NextResponse.json({ success: true, key, url }, { status: 200 });
  } catch (error) {
    console.error('Upload error:', error);
    return NextResponse.json({ error: 'Erreur serveur lors de l\'upload' }, { status: 500 });
  }
}
