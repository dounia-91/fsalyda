import dbConnect from "@/lib/dbConnect";
import NotificationModel from "@/model/notification";
import { NextRequest, NextResponse } from "next/server";

/**
 * POST /api/createNotification
 * Crée une notification ciblée pour un utilisateur.
 * Body: { title: string, message: string, fromUser: string, toUser: string }
 * 
 * Correction: le schéma NotificationModel nécessite fromUser et toUser,
 * l'ancienne version envoyait uniquement title, message, from (incomplet).
 */
export async function POST(req: NextRequest) {
  await dbConnect();
  try {
    const { title, message, fromUser, toUser } = await req.json();

    if (!title || !message || !fromUser || !toUser) {
      return NextResponse.json(
        { success: false, message: "title, message, fromUser et toUser sont requis" },
        { status: 400 }
      );
    }

    const notification = new NotificationModel({ title, message, fromUser, toUser });
    await notification.save();

    return NextResponse.json(
      { success: true, message: "Notification créée avec succès" },
      { status: 200 }
    );
  } catch (error) {
    console.error("Erreur création notification:", error);
    return NextResponse.json(
      { success: false, message: "Erreur lors de la création de la notification" },
      { status: 500 }
    );
  }
}
