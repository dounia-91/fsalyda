import dbConnect from "@/lib/dbConnect";
import NotificationModel from "@/model/notification";
import { NextRequest, NextResponse } from "next/server";

/**
 * POST /api/getNotifications
 * Récupère les notifications d'un utilisateur.
 * Body: { email: string }
 * 
 * Correction: utilise une requête MongoDB ciblée au lieu de charger toutes
 * les notifications en mémoire et filtrer en JS.
 */
export async function POST(request: NextRequest) {
  await dbConnect();
  try {
    const { email } = await request.json();

    if (!email) {
      return NextResponse.json({ success: false, message: "Email requis" }, { status: 400 });
    }

    // Requête ciblée directement en base, triée par date décroissante
    const notifications = await NotificationModel
      .find({ toUser: email })
      .sort({ createdAt: -1 })
      .limit(50);

    if (!notifications || notifications.length === 0) {
      return NextResponse.json(
        { success: false, message: "Aucune notification" },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { success: true, message: "Notifications récupérées", notifications },
      { status: 200 }
    );
  } catch (error) {
    console.error("Erreur récupération notifications:", error);
    return NextResponse.json(
      { success: false, message: "Erreur serveur" },
      { status: 500 }
    );
  }
}
