import { NextRequest, NextResponse } from "next/server";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

/**
 * GET /api/image-proxy?key=uploads/mon-fichier.jpg
 * Proxy pour accéder aux fichiers S3 privés depuis le navigateur.
 * Utilise AWS_S3_BUCKET (unifié avec la variable dans .env.example).
 * 
 * Correction: l'ancienne version utilisait S3_BUCKET_NAME (inconsistant),
 * on utilise maintenant AWS_S3_BUCKET || AWS_BUCKET_NAME pour compatibilité.
 */
const s3 = new S3Client({
  region: process.env.AWS_REGION!,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
});

export async function GET(req: NextRequest) {
  const key = new URL(req.url).searchParams.get("key");

  if (!key) {
    return NextResponse.json({ error: "Paramètre 'key' manquant" }, { status: 400 });
  }

  const bucket = process.env.AWS_S3_BUCKET || process.env.AWS_BUCKET_NAME;
  if (!bucket) {
    return NextResponse.json({ error: "Bucket S3 non configuré" }, { status: 500 });
  }

  try {
    const command = new GetObjectCommand({ Bucket: bucket, Key: key });
    const s3Response = await s3.send(command);

    const body = s3Response.Body as ReadableStream<Uint8Array>;
    const contentType = s3Response.ContentType || "application/octet-stream";

    return new NextResponse(body, {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch (err) {
    console.error("Erreur proxy S3:", err);
    return NextResponse.json(
      { error: "Fichier introuvable ou accès S3 refusé" },
      { status: 404 }
    );
  }
}
