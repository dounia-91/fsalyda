"use client";
/**
 * ShareFormModal
 * Modal de partage d'un formulaire rempli.
 * Fonctionnalités:
 * - Copie du lien de partage
 * - Génération de QR code (via API qrserver.com)
 * - Téléchargement PDF (via window.print / CSS @media print)
 * - Envoi par email (via mailto:)
 * - Verrouillage du formulaire
 */
import { useState, useEffect } from "react";
import { X, Link2, QrCode, FileDown, Mail, Lock, Unlock, Loader2, Check } from "lucide-react";
import Image from "next/image";

interface Props {
  formId: string;
  formTitle: string;
  isLocked: boolean;
  onClose: () => void;
  onLockChange?: (locked: boolean) => void;
}

export default function ShareFormModal({ formId, formTitle, isLocked, onClose, onLockChange }: Props) {
  const [shareUrl, setShareUrl] = useState("");
  const [loadingShare, setLoadingShare] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [lockLoading, setLockLoading] = useState(false);
  const [locked, setLocked] = useState(isLocked);
  const [emailTo, setEmailTo] = useState("");

  // Générer le lien de partage au montage
  useEffect(() => {
    const generateLink = async () => {
      setLoadingShare(true);
      try {
        const res = await fetch("/api/share", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ formId }),
        });
        const data = await res.json();
        if (data.success) setShareUrl(data.shareUrl);
      } catch {
        console.error("Erreur génération lien");
      } finally {
        setLoadingShare(false);
      }
    };
    generateLink();
  }, [formId]);

  const copyLink = async () => {
    if (!shareUrl) return;
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadPDF = () => {
    window.print();
  };

  const sendEmail = () => {
    if (!emailTo.trim() || !shareUrl) return;
    const subject = encodeURIComponent(`Formulaire partagé: ${formTitle}`);
    const body = encodeURIComponent(
      `Bonjour,\n\nVous avez accès au formulaire "${formTitle}" via ce lien:\n${shareUrl}\n\nCordialement`
    );
    window.open(`mailto:${emailTo}?subject=${subject}&body=${body}`);
  };

  const toggleLock = async () => {
    setLockLoading(true);
    try {
      const res = await fetch("/api/lockForm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ formId, lock: !locked }),
      });
      const data = await res.json();
      if (data.success) {
        setLocked(data.isLocked);
        onLockChange?.(data.isLocked);
      }
    } catch {
      console.error("Erreur verrouillage");
    } finally {
      setLockLoading(false);
    }
  };

  const qrUrl = shareUrl
    ? `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(shareUrl)}`
    : "";

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="font-bold text-gray-800">Partager le formulaire</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X size={20} />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Titre */}
          <p className="text-sm text-gray-500">
            <span className="font-medium text-gray-700">{formTitle}</span>
          </p>

          {/* Lien de partage */}
          <div>
            <label className="text-xs font-medium text-gray-500 uppercase tracking-wide block mb-1">
              Lien de partage
            </label>
            {loadingShare ? (
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <Loader2 size={14} className="animate-spin" /> Génération...
              </div>
            ) : (
              <div className="flex gap-2">
                <input
                  type="text"
                  value={shareUrl}
                  readOnly
                  className="flex-1 border rounded-lg px-3 py-2 text-sm bg-gray-50 text-gray-700 truncate"
                />
                <button
                  onClick={copyLink}
                  className="flex items-center gap-1 bg-blue-500 text-white px-3 py-2 rounded-lg text-sm hover:bg-blue-600"
                >
                  {copied ? <Check size={14} /> : <Link2 size={14} />}
                  {copied ? "Copié !" : "Copier"}
                </button>
              </div>
            )}
          </div>

          {/* QR Code */}
          <div>
            <button
              onClick={() => setShowQR(!showQR)}
              className="flex items-center gap-2 text-sm text-gray-600 hover:text-blue-600"
            >
              <QrCode size={16} />
              {showQR ? "Masquer" : "Afficher"} le QR code
            </button>
            {showQR && qrUrl && (
              <div className="mt-2 flex flex-col items-center gap-2">
                <Image src={qrUrl} alt="QR Code" width={200} height={200} className="border rounded-lg" />
                <a
                  href={qrUrl}
                  download={`qr-${formTitle}.png`}
                  className="text-xs text-blue-500 hover:underline"
                >
                  Télécharger le QR code
                </a>
              </div>
            )}
          </div>

          {/* Envoi par email */}
          <div>
            <label className="text-xs font-medium text-gray-500 uppercase tracking-wide block mb-1">
              Envoyer par email
            </label>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="destinataire@exemple.com"
                value={emailTo}
                onChange={(e) => setEmailTo(e.target.value)}
                className="flex-1 border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
              />
              <button
                onClick={sendEmail}
                disabled={!emailTo.trim() || !shareUrl}
                className="flex items-center gap-1 bg-green-500 text-white px-3 py-2 rounded-lg text-sm hover:bg-green-600 disabled:opacity-50"
              >
                <Mail size={14} />
                Envoyer
              </button>
            </div>
          </div>

          {/* PDF */}
          <button
            onClick={downloadPDF}
            className="w-full flex items-center justify-center gap-2 border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-gray-50"
          >
            <FileDown size={16} />
            Télécharger en PDF
          </button>

          {/* Verrouillage */}
          <div className="border-t pt-3">
            <button
              onClick={toggleLock}
              disabled={lockLoading}
              className={`w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium ${
                locked
                  ? "bg-orange-100 text-orange-700 hover:bg-orange-200"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {lockLoading ? (
                <Loader2 size={14} className="animate-spin" />
              ) : locked ? (
                <Unlock size={14} />
              ) : (
                <Lock size={14} />
              )}
              {locked ? "Déverrouiller le formulaire" : "Verrouiller le formulaire"}
            </button>
            <p className="text-xs text-gray-400 text-center mt-1">
              {locked
                ? "Ce formulaire est en lecture seule. Les commentaires sont désactivés."
                : "Verrouiller empêche toute modification et désactive les commentaires."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
