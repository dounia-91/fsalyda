"use client";
/**
 * RenderAttachedFile
 * Composant de gestion des pièces jointes.
 * Corrections:
 * - Gestion correcte des non-images (PDF, DOCX, etc.) sans URL.createObjectURL dans Image
 * - Suppression fonctionnelle avec renommage correct
 * - Limite de taille configurable (10 MB par défaut)
 * - Mode preview: affiche les liens vers les fichiers S3
 */
import { FormItemDetails, FormState } from "@/types/types";
import { useRef } from "react";
import { toast } from "react-toastify";
import Link from "next/link";
import { FileText, X, Upload } from "lucide-react";

type Props = {
  itemD: FormItemDetails;
  preview?: boolean;
  formState: FormState;
  setFormState: React.Dispatch<React.SetStateAction<FormState>>;
};

const MAX_FILE_SIZE_MB = 10;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

// Extensions d'images supportées pour prévisualisation
const IMAGE_EXTENSIONS = ["jpg", "jpeg", "png", "gif", "webp", "svg"];

const isImageFile = (file: File) => {
  const ext = file.name.split(".").pop()?.toLowerCase() || "";
  return IMAGE_EXTENSIONS.includes(ext) || file.type.startsWith("image/");
};

export default function RenderAttachedFile({
  itemD,
  formState,
  setFormState,
  preview,
}: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentFiles = (formState[itemD.newTitle] as File[]) || [];
  const currentUrls = (formState[itemD.newTitle] as string[]) || [];

  const validateFiles = (files: File[]): boolean => {
    if (!itemD.multipleAttachments && files.length > 1) {
      toast("Un seul fichier autorisé", { type: "error" });
      return false;
    }
    for (const file of files) {
      if (file.size > MAX_FILE_SIZE_BYTES) {
        toast(`"${file.name}" dépasse la limite de ${MAX_FILE_SIZE_MB} MB`, { type: "error" });
        return false;
      }
    }
    return true;
  };

  const addFiles = (newFiles: File[]) => {
    if (!validateFiles(newFiles)) return;
    const combined = itemD.multipleAttachments
      ? [...currentFiles, ...newFiles]
      : [...newFiles];
    setFormState((prev) => ({ ...prev, [itemD.newTitle]: combined }));
  };

  const removeFile = (index: number) => {
    const updated = currentFiles.filter((_, i) => i !== index);
    setFormState((prev) => ({ ...prev, [itemD.newTitle]: updated }));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    addFiles(files);
    // Reset l'input pour permettre de re-sélectionner le même fichier
    e.target.value = "";
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    addFiles(files);
  };

  return (
    <div className="w-full flex flex-col items-start justify-start space-y-2">
      <p
        className={`font-bold text-${itemD.newColor} ${
          itemD.size === "smaller" ? "text-md" : itemD.size === "normal" ? "text-lg" : "text-xl"
        }`}
      >
        {itemD.newTitle} :
      </p>

      {preview ? (
        // Mode lecture seule: liens S3
        <ul className="w-full bg-white rounded-lg p-2 flex flex-col space-y-1">
          {currentUrls.length === 0 && (
            <li className="text-gray-400 text-sm">Aucun fichier joint</li>
          )}
          {currentUrls.map((url, index) => (
            <li
              key={index}
              className="w-full flex items-center gap-2 border border-gray-300 rounded-lg p-1"
            >
              <FileText size={16} className="text-blue-500 shrink-0" />
              <Link
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline truncate"
              >
                Fichier {index + 1}
              </Link>
            </li>
          ))}
        </ul>
      ) : (
        // Mode saisie
        <div className="w-full space-y-2">
          <input
            type="file"
            multiple={itemD.multipleAttachments}
            onChange={handleChange}
            ref={fileInputRef}
            className="hidden"
          />

          {/* Zone de dépôt */}
          <div
            className="w-full min-h-[100px] bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-4 flex flex-col items-center justify-center cursor-pointer hover:border-blue-400 transition-colors"
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
          >
            <Upload size={24} className="text-gray-400 mb-2" />
            <span className="text-sm text-gray-500 text-center">
              Cliquez ou glissez-déposez vos fichiers ici
              <br />
              <span className="text-xs">(Max {MAX_FILE_SIZE_MB} MB par fichier)</span>
            </span>
          </div>

          {/* Liste des fichiers sélectionnés */}
          {currentFiles.length > 0 && (
            <ul className="space-y-1">
              {currentFiles.map((file, index) => (
                <li
                  key={index}
                  className="flex items-center justify-between border border-gray-300 rounded-lg p-2 bg-white"
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    {isImageFile(file) ? (
                      // Prévisualisation pour les images
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={URL.createObjectURL(file)}
                        alt={file.name}
                        className="w-10 h-10 object-cover rounded"
                      />
                    ) : (
                      <FileText size={20} className="text-blue-500 shrink-0" />
                    )}
                    <span className="text-sm truncate">
                      {file.name}{" "}
                      <span className="text-gray-400">
                        ({(file.size / 1024).toFixed(1)} KB)
                      </span>
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeFile(index)}
                    className="text-red-500 hover:text-red-700 shrink-0 ml-2"
                    title="Supprimer"
                  >
                    <X size={16} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
