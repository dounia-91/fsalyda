"use client";
/**
 * RenderPhoto (fillForm)
 * Composant de saisie de photos dans un formulaire.
 * - Mode saisie: sélection/capture de photos, prévisualisation, suppression, réorganisation
 * - Mode preview: affiche les photos depuis les URLs S3
 * 
 * Note: L'upload vers S3 se fait dans saveFilledForm.ts (Server Action) lors de la soumission.
 * Ce composant gère uniquement les objets File locaux avant envoi.
 */
import { useRef } from "react";
import Image from "next/image";
import { FormItemDetails, FormState } from "@/types/types";
import { Trash2, Upload } from "lucide-react";
import { toast } from "react-toastify";

type Props = {
  itemD: FormItemDetails;
  formState: FormState;
  preview?: boolean;
  setFormState: React.Dispatch<React.SetStateAction<FormState>>;
};

const MAX_SIZE_MB = 5;

export default function RenderPhoto({ itemD, formState, setFormState, preview }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentFiles = (formState[itemD.newTitle] as File[]) || [];
  const currentUrls = (formState[itemD.newTitle] as string[]) || [];

  const validateAndAdd = (files: File[]) => {
    const maxSize = MAX_SIZE_MB * 1024 * 1024;
    const validFiles: File[] = [];

    for (const file of files) {
      if (!file.type.startsWith("image/")) {
        toast(`"${file.name}" n'est pas une image`, { type: "error" });
        continue;
      }
      if (file.size > maxSize) {
        toast(`"${file.name}" dépasse ${MAX_SIZE_MB} MB`, { type: "error" });
        continue;
      }
      validFiles.push(file);
    }

    if (validFiles.length === 0) return;

    const limit = itemD.maxPics || 10;
    const combined = [...currentFiles, ...validFiles].slice(0, limit);

    if (currentFiles.length + validFiles.length > limit) {
      toast(`Maximum ${limit} photo(s) autorisée(s)`, { type: "warning" });
    }

    setFormState((prev) => ({ ...prev, [itemD.newTitle]: combined }));
  };

  const removeFile = (index: number) => {
    const updated = currentFiles.filter((_, i) => i !== index);
    setFormState((prev) => ({ ...prev, [itemD.newTitle]: updated }));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    validateAndAdd(files);
    e.target.value = "";
  };

  const textSize =
    itemD.size === "smaller" ? "text-md" : itemD.size === "normal" ? "text-lg" : "text-xl";

  return (
    <div className="w-full flex flex-col items-start justify-start space-y-2">
      <p className={`font-bold text-${itemD.newColor} ${textSize}`}>
        {itemD.newTitle} :
      </p>

      {preview ? (
        // Mode lecture seule: photos depuis S3
        <div className="flex flex-wrap gap-3">
          {currentUrls.length === 0 && (
            <span className="text-gray-400 text-sm">Aucune photo</span>
          )}
          {currentUrls.map((url, i) => (
            <div key={i} className="relative w-32 h-32 rounded-lg overflow-hidden border border-gray-200">
              <Image
                src={url}
                alt={`Photo ${i + 1}`}
                fill
                className="object-cover"
                sizes="128px"
              />
            </div>
          ))}
        </div>
      ) : (
        // Mode saisie
        <div className="w-full space-y-2">
          <input
            type="file"
            accept="image/*"
            multiple={itemD.multiplePics !== false}
            onChange={handleChange}
            ref={fileInputRef}
            className="hidden"
          />

          {/* Zone de sélection */}
          <div
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              validateAndAdd(Array.from(e.dataTransfer.files));
            }}
            className="w-full min-h-[80px] border-2 border-dashed border-gray-300 rounded-lg p-3 flex flex-col items-center justify-center cursor-pointer hover:border-blue-400 transition-colors bg-gray-50"
          >
            <Upload size={20} className="text-gray-400 mb-1" />
            <span className="text-sm text-gray-500 text-center">
              Cliquez ou déposez des photos ici
              <br />
              <span className="text-xs">(Max {MAX_SIZE_MB} MB, {itemD.maxPics || 10} photos)</span>
            </span>
          </div>

          {/* Grille de prévisualisation */}
          {currentFiles.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {currentFiles.map((file, i) => {
                const url = URL.createObjectURL(file);
                return (
                  <div key={i} className="relative w-28 h-28 rounded-lg overflow-hidden border border-gray-200 group">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={url}
                      alt={file.name}
                      className="w-full h-full object-cover"
                      onLoad={() => URL.revokeObjectURL(url)}
                    />
                    <button
                      type="button"
                      onClick={() => removeFile(i)}
                      className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Supprimer"
                    >
                      <Trash2 size={12} />
                    </button>
                    <span className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-xs px-1 py-0.5 truncate">
                      {file.name}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
