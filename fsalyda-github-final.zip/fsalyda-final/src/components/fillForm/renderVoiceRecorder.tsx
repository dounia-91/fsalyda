"use client";
/**
 * RenderVoiceRecorder
 * Composant d'enregistrement audio.
 * - Enregistre via MediaRecorder (navigateur)
 * - En mode preview: affiche l'audio depuis une URL S3
 * - NOTE: L'upload vers S3 se fait dans saveFilledForm.ts (Server Action),
 *   pas ici côté client (les credentials AWS ne doivent jamais être dans le client).
 */
import { useEffect, useRef, useState } from "react";
import { FormItemDetails, FormState } from "@/types/types";

type Props = {
  itemD: FormItemDetails;
  formState: FormState;
  preview?: boolean;
  setFormState: React.Dispatch<React.SetStateAction<FormState>>;
};

export default function RenderVoiceRecorder({
  itemD,
  formState,
  setFormState,
  preview,
}: Props) {
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  // En mode preview: lire l'URL S3 stockée dans formState
  useEffect(() => {
    if (preview) {
      const value = formState[itemD.newTitle];
      if (typeof value === "string" && value.startsWith("http")) {
        setAudioUrl(value);
      }
    }
  }, [preview, formState, itemD.newTitle]);

  // Nettoyer l'URL objet en mémoire lors du démontage
  useEffect(() => {
    return () => {
      if (audioUrl && audioUrl.startsWith("blob:")) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  const startRecording = async () => {
    try {
      chunksRef.current = [];
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      // Choisir le format supporté par le navigateur
      const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : "audio/webm";

      const recorder = new MediaRecorder(stream, { mimeType });

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        // Arrêter toutes les pistes micro
        stream.getTracks().forEach((t) => t.stop());

        const blob = new Blob(chunksRef.current, { type: mimeType });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);

        // Stocker les chunks dans formState (sera uploadé lors de la soumission)
        setFormState((prev) => ({
          ...prev,
          [itemD.newTitle]: chunksRef.current,
        }));

        clearInterval(intervalRef.current!);
        setRecordingTime(0);
      };

      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setRecordingTime(0);
      intervalRef.current = setInterval(() => {
        setRecordingTime((t) => t + 1);
      }, 1000);
    } catch (error) {
      console.error("Erreur accès microphone:", error);
      alert("Impossible d'accéder au microphone. Vérifiez les permissions.");
    }
  };

  const stopRecording = () => {
    setIsRecording(false);
    mediaRecorderRef.current?.stop();
  };

  const deleteRecording = () => {
    if (audioUrl && audioUrl.startsWith("blob:")) {
      URL.revokeObjectURL(audioUrl);
    }
    setAudioUrl(null);
    chunksRef.current = [];
    setFormState((prev) => ({ ...prev, [itemD.newTitle]: [] }));
    if (intervalRef.current) clearInterval(intervalRef.current);
    setRecordingTime(0);
  };

  const downloadRecording = () => {
    if (!audioUrl) return;
    const a = document.createElement("a");
    a.href = audioUrl;
    a.download = `${itemD.newTitle || "enregistrement"}.webm`;
    a.click();
  };

  const textSize =
    itemD.size === "smaller" ? "text-md" : itemD.size === "normal" ? "text-lg" : "text-xl";

  return (
    <div className="w-full flex flex-col items-start justify-start space-y-2">
      <p className={`w-full text-${itemD.newColor} ${textSize}`}>
        {itemD.newTitle} :
      </p>

      {preview ? (
        // Mode lecture seule: afficher le player audio
        <div className="w-full">
          {audioUrl ? (
            <audio src={audioUrl} controls className="w-full" />
          ) : (
            <span className="text-gray-400 text-sm">Aucun enregistrement</span>
          )}
        </div>
      ) : (
        // Mode saisie: contrôles d'enregistrement
        <div className="w-full flex flex-col gap-2">
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={startRecording}
              disabled={isRecording}
              className="p-2 rounded-lg text-white bg-green-500 disabled:bg-green-200 text-xl"
              title="Démarrer l'enregistrement"
            >
              🎤
            </button>
            <button
              type="button"
              onClick={stopRecording}
              disabled={!isRecording}
              className="p-2 rounded-lg text-white bg-red-500 disabled:bg-red-200 text-xl"
              title="Arrêter l'enregistrement"
            >
              ⏹️
            </button>
            {isRecording && (
              <span className="ml-2 font-mono text-lg text-red-600">
                ● {formatTime(recordingTime)}
              </span>
            )}
          </div>

          {audioUrl && (
            <div className="flex flex-col gap-2">
              <audio src={audioUrl} controls className="w-full" />
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={deleteRecording}
                  className="p-2 rounded-lg bg-gray-300 hover:bg-gray-400 text-black text-xl"
                  title="Supprimer l'enregistrement"
                >
                  🗑️
                </button>
                <button
                  type="button"
                  onClick={downloadRecording}
                  className="p-2 rounded-lg bg-blue-500 hover:bg-blue-600 text-white text-xl"
                  title="Télécharger"
                >
                  ⬇️
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
