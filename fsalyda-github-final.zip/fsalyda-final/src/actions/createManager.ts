"use server";
import dbConnect from "@/lib/dbConnect";
import bcrypt from "bcryptjs";
import AdminModel, { Admin } from "@/model/admin";
import BusinessUserModel from "@/model/businessUser";
import NotificationModel from "@/model/notification";
import UserModel from "@/model/user";

/**
 * CreateManager
 * Crée un compte Manager (BusinessUser) pour une entreprise.
 * Correction: vérifie la limite maxUsers de l'entreprise avant création.
 */
export const CreateManager = async (formData: FormData, creatorEmail: string) => {
  await dbConnect();
  try {
    const companyName = formData.get("companyName")!.toString().toLowerCase();
    const fullName = formData.get("fullName")!.toString();
    const email = formData.get("email")!.toString().toLowerCase();
    const password = formData.get("password")!.toString();
    const maxUsersRaw = formData.get("maxUsers");
    const maxUsers = maxUsersRaw ? parseInt(maxUsersRaw.toString()) : 10;

    if (maxUsers < 1) {
      return { success: false, message: "Le nombre maximum d'utilisateurs doit être au moins 1.", status: 400 };
    }

    const existingUser = await BusinessUserModel.findOne({ email });
    if (existingUser) {
      return { success: false, message: "Un compte avec cet email existe déjà.", status: 200 };
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newManager = new BusinessUserModel({
      companyName,
      name: fullName,
      email,
      password: hashedPassword,
      maxUsers,
      isVerified: true,
      role: "manager",
    });
    await newManager.save();

    // Notifications aux admins
    const admins = await AdminModel.find({});
    const toUsers = admins
      .map((a: Admin) => a.email)
      .filter((e) => e !== creatorEmail && e !== email);

    await Promise.all(
      toUsers.map((u) =>
        new NotificationModel({
          title: "Nouveau manager créé",
          message: `Le compte manager ${email} (entreprise: ${companyName}, max ${maxUsers} users) a été créé par ${creatorEmail}.`,
          fromUser: creatorEmail,
          toUser: u,
        }).save()
      )
    );

    return { success: true, message: "Compte manager créé avec succès.", status: 200 };
  } catch (e) {
    console.error("Erreur création manager:", e);
    return { success: false, message: "Erreur lors de la création du manager.", status: 500 };
  }
};
