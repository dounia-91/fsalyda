"use server";
import dbConnect from "@/lib/dbConnect";
import FilledFormModel from "@/model/filledForm";
import AdminModel, { Admin } from "@/model/admin";
import BusinessUserModel, { BusinessUser } from "@/model/businessUser";
import NotificationModel from "@/model/notification";
import { uploadFileToS3, uploadBlobToS3 } from "@/lib/s3config";
import { FormItemDetails } from "@/types/types";

/**
 * SaveFilledForm
 * Server Action appelée depuis fillForm.tsx lors de la soumission d'un formulaire.
 * - Upload les fichiers (photos, audio, pièces jointes) vers S3
 * - Sauvegarde le formulaire rempli dans MongoDB
 * - Crée les notifications pour admins et managers
 */
export async function SaveFilledForm(
  companyName: string,
  formTitle: string,
  recordData: FormData,
  formItemDetails: FormItemDetails[],
  filledByEmail: string
) {
  await dbConnect();

  try {
    // Construire formState en traitant chaque champ selon son type
    const formState: Record<string, unknown> = {};

    for (const itemD of formItemDetails) {
      const key = itemD.newTitle;

      if (itemD.title === "Photo" || itemD.title === "Attached file") {
        // Récupérer tous les fichiers de ce champ
        const uploadedUrls: string[] = [];
        let i = 0;
        while (true) {
          const file = recordData.get(`${key}[${i}]`) as File | null;
          if (!file) break;
          const result = await uploadFileToS3(file);
          if (result.success && result.url) {
            uploadedUrls.push(result.url);
          } else {
            console.error(`Échec upload fichier ${file.name}:`, result.error);
          }
          i++;
        }
        formState[key] = uploadedUrls;

      } else if (itemD.title === "Voice Recorder") {
        // Upload de l'enregistrement audio
        const blob = recordData.get(key) as Blob | null;
        if (blob && blob.size > 0) {
          const result = await uploadBlobToS3(blob, "audio/webm;codecs=opus");
          formState[key] = result.success ? result.url : "";
        } else {
          formState[key] = "";
        }

      } else if (itemD.title === "List" && itemD.listMultipleSelection) {
        // Liste multi-sélection: tableau de strings
        const values: string[] = [];
        let i = 0;
        while (true) {
          const val = recordData.get(`${key}[${i}]`) as string | null;
          if (val === null) break;
          values.push(val);
          i++;
        }
        formState[key] = values;

      } else if (itemD.title === "Table") {
        // Table: tableau 2D de strings
        const rowCountStr = recordData.get(`${key}RowCount`) as string;
        const rowCount = parseInt(rowCountStr || "0");
        const tableData: string[][] = [];
        for (let r = 0; r < rowCount; r++) {
          const row: string[] = [];
          let c = 0;
          while (true) {
            const cell = recordData.get(`${key}[${r}][${c}]`) as string | null;
            if (cell === null) break;
            row.push(cell);
            c++;
          }
          if (row.length > 0) tableData.push(row);
        }
        formState[key] = tableData;
        formState[`${key}RowCount`] = rowCountStr;

      } else {
        // Champ simple (texte, date, checkbox, etc.)
        formState[key] = recordData.get(key) as string ?? "";
      }
    }

    // Sauvegarde dans MongoDB
    const newFilledForm = new FilledFormModel({
      title: formTitle,
      companyName,
      filledBy: filledByEmail,
      formItemDetails,
      formState,
    });
    await newFilledForm.save();

    // Notifications: admins + managers de la même entreprise
    const admins = await AdminModel.find({});
    const managers = await BusinessUserModel.find({ companyName });

    const recipients: string[] = [
      ...admins.map((a: Admin) => a.email),
      ...managers.map((m: BusinessUser) => m.email),
    ].filter((email) => email !== filledByEmail);

    // Dédoublonner
    const uniqueRecipients = [...new Set(recipients)];

    await Promise.all(
      uniqueRecipients.map((toUser) =>
        new NotificationModel({
          title: "Nouveau formulaire soumis",
          message: `Le formulaire "${formTitle}" a été rempli par ${filledByEmail}`,
          fromUser: filledByEmail,
          toUser,
        }).save()
      )
    );

    return {
      success: true,
      message: "Formulaire enregistré avec succès",
    };
  } catch (error) {
    console.error("Erreur SaveFilledForm:", error);
    return {
      success: false,
      message: "Erreur lors de l'enregistrement du formulaire",
    };
  }
}
