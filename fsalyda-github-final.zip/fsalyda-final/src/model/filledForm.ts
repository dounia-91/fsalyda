import { FormState } from "@/types/types";
import { FormItemDetails } from "@/types/types";
import mongoose, { Schema, Document } from "mongoose";

export interface Comment {
  author: string;
  text: string;
  createdAt: Date;
}

/**
 * FilledForm - Formulaire rempli et sauvegardé.
 * Nouveaux champs:
 * - shareToken: token unique pour le partage par lien
 * - isLocked: formulaire verrouillé (lecture seule)
 * - lockedAt: date de verrouillage
 * - comments: commentaires des destinataires
 */
export interface FilledForm extends Document {
  title: string;
  formItemDetails: FormItemDetails[];
  formState: FormState;
  filledBy: string;
  createdAt: Date;
  companyName: string;
  shareToken?: string;
  isLocked: boolean;
  lockedAt?: Date;
  comments: Comment[];
}

const CommentSchema = new mongoose.Schema({
  author: { type: String, required: true },
  text: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

export const FilledFormSchema: Schema<FilledForm> = new mongoose.Schema({
  title: { type: String, required: true },
  formItemDetails: { type: [], required: true },
  formState: { type: {}, required: true },
  filledBy: { type: String, required: true },
  createdAt: { type: Date, required: true, default: Date.now },
  companyName: { type: String, required: true },
  // Partage
  shareToken: { type: String, unique: true, sparse: true },
  // Verrouillage
  isLocked: { type: Boolean, default: false },
  lockedAt: { type: Date },
  // Commentaires collaboration
  comments: { type: [CommentSchema], default: [] },
});

// Index pour accès rapide par token de partage
FilledFormSchema.index({ shareToken: 1 });
// Index pour historique par utilisateur/entreprise
FilledFormSchema.index({ filledBy: 1, createdAt: -1 });
FilledFormSchema.index({ companyName: 1, createdAt: -1 });

const FilledFormModel =
  (mongoose.models.FilledForms as mongoose.Model<FilledForm>) ||
  mongoose.model<FilledForm>("FilledForms", FilledFormSchema);

export default FilledFormModel;
